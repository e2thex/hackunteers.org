This module provides back references for CCK's nodereference.module.
